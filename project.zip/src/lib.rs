pub mod filter_list;

use std::collections::HashMap;
use std::ffi::CStr;
use std::fs::File;
use std::io::{BufReader, BufWriter, Read, Write};
use std::os::raw::c_char;

/// A radix tree node for efficient domain matching
#[derive(Debug)]
struct RadixNode {
    /// The string fragment this node represents
    prefix: String,
    /// Whether this node marks a blocked domain (universal block)
    is_blocked: bool,
    /// Origins where this domain should NOT be blocked (whitelist/exceptions)
    whitelist_origins: Option<Vec<String>>,
    /// Origins where this domain should ONLY be blocked (conditional blocking)
    blacklist_origins: Option<Vec<String>>,
    /// Child nodes
    children: HashMap<char, Box<RadixNode>>,
}

impl RadixNode {
    fn new(prefix: String, is_blocked: bool) -> Self {
        RadixNode {
            prefix,
            is_blocked,
            whitelist_origins: None,
            blacklist_origins: None,
            children: HashMap::new(),
        }
    }
}

/// The main domain tree structure
pub struct DomainTree {
    root: RadixNode,
}

impl DomainTree {
    pub fn new() -> Self {
        DomainTree {
            root: RadixNode::new(String::new(), false),
        }
    }

    /// Reverse a domain: "ads.example.com" -> "com.example.ads"
    fn reverse_domain(domain: &str) -> String {
        domain.split('.').rev().collect::<Vec<_>>().join(".")
    }

    /// Insert a domain into the tree (universal block)
    pub fn insert(&mut self, domain: &str) -> bool {
        if domain.is_empty() {
            return false;
        }

        let reversed = Self::reverse_domain(domain);
        self.insert_reversed(&reversed, true, None, None)
    }

    /// Insert a domain with whitelist origin (exception rule)
    pub fn insert_with_whitelist(&mut self, domain: &str, origin: &str) -> bool {
        if domain.is_empty() || origin.is_empty() {
            return false;
        }

        let reversed = Self::reverse_domain(domain);
        let reversed_origin = Self::reverse_domain(origin);
        self.insert_reversed(&reversed, false, Some(reversed_origin), None)
    }

    /// Insert a domain with blacklist origin (only-if rule)
    pub fn insert_with_blacklist(&mut self, domain: &str, origin: &str) -> bool {
        if domain.is_empty() || origin.is_empty() {
            return false;
        }

        let reversed = Self::reverse_domain(domain);
        let reversed_origin = Self::reverse_domain(origin);
        self.insert_reversed(&reversed, false, None, Some(reversed_origin))
    }

    fn insert_reversed(
        &mut self,
        reversed: &str,
        is_universal_block: bool,
        whitelist_origin: Option<String>,
        blacklist_origin: Option<String>,
    ) -> bool {
        let mut current = &mut self.root;
        let mut remaining = reversed;

        loop {
            if remaining.is_empty() {
                // Update the node with new rules
                if is_universal_block {
                    current.is_blocked = true;
                }

                if let Some(origin) = whitelist_origin {
                    current
                        .whitelist_origins
                        .get_or_insert_with(Vec::new)
                        .push(origin);
                }

                if let Some(origin) = blacklist_origin {
                    current
                        .blacklist_origins
                        .get_or_insert_with(Vec::new)
                        .push(origin);
                }

                return true;
            }

            let first_char = remaining.chars().next().unwrap();

            // Check if we need to split - determine this before any mutable borrows
            let needs_split = if let Some(child) = current.children.get(&first_char) {
                let common_len = Self::common_prefix_len(&child.prefix, remaining);
                common_len > 0 && common_len < child.prefix.len()
            } else {
                false
            };

            if needs_split {
                // Extract all data needed before any interning
                let (prefix, common_len, new_suffix_str) = {
                    let child = current.children.get(&first_char).unwrap();
                    let prefix = child.prefix.clone();
                    let common_len = Self::common_prefix_len(&prefix, remaining);
                    let new_suffix_str = remaining[common_len..].to_string();
                    (prefix, common_len, new_suffix_str)
                };

                // Intern all strings (no borrows of current during interning)
                let common = prefix[..common_len].to_string();
                let old_suffix = prefix[common_len..].to_string();
                let new_suffix = if !new_suffix_str.is_empty() {
                    Some(new_suffix_str)
                } else {
                    None
                };

                // Now mutably borrow and modify
                let child = current.children.get_mut(&first_char).unwrap();

                // Create new intermediate node
                let mut intermediate = RadixNode::new(common, false);

                // Move old node down
                let old_node =
                    std::mem::replace(child.as_mut(), RadixNode::new(String::new(), false));
                let old_first_char = old_suffix.chars().next().unwrap();
                let mut old_child = Box::new(old_node);
                old_child.prefix = old_suffix;
                intermediate.children.insert(old_first_char, old_child);

                // Insert new branch
                if let Some(new_suffix) = new_suffix {
                    let new_first_char = new_suffix.chars().next().unwrap();
                    let mut new_node = RadixNode::new(new_suffix, false);

                    if is_universal_block {
                        new_node.is_blocked = true;
                    }
                    if let Some(origin) = whitelist_origin {
                        new_node.whitelist_origins = Some(vec![origin]);
                    }
                    if let Some(origin) = blacklist_origin {
                        new_node.blacklist_origins = Some(vec![origin]);
                    }

                    intermediate
                        .children
                        .insert(new_first_char, Box::new(new_node));
                } else {
                    if is_universal_block {
                        intermediate.is_blocked = true;
                    }
                    if let Some(origin) = whitelist_origin {
                        intermediate.whitelist_origins = Some(vec![origin]);
                    }
                    if let Some(origin) = blacklist_origin {
                        intermediate.blacklist_origins = Some(vec![origin]);
                    }
                }

                *child.as_mut() = intermediate;
                return true;
            }

            // Check if child exists and handle it
            let child_exists = current.children.contains_key(&first_char);

            if child_exists {
                let child = current.children.get_mut(&first_char).unwrap();
                let common_len = Self::common_prefix_len(&child.prefix, remaining);

                if common_len == 0 {
                    return false;
                }

                if common_len == child.prefix.len() {
                    // Full prefix match, continue down
                    remaining = &remaining[common_len..];
                    current = child;
                } else {
                    unreachable!();
                }
            } else {
                // No matching child - create new node
                let new_prefix = remaining.to_string();
                let mut new_node = RadixNode::new(new_prefix, false);

                if is_universal_block {
                    new_node.is_blocked = true;
                }
                if let Some(origin) = whitelist_origin {
                    new_node.whitelist_origins = Some(vec![origin]);
                }
                if let Some(origin) = blacklist_origin {
                    new_node.blacklist_origins = Some(vec![origin]);
                }

                current.children.insert(first_char, Box::new(new_node));
                return true;
            }
        }
    }

    /// Check if a domain is blocked (no context)
    pub fn is_blocked(&self, domain: &str) -> bool {
        self.is_blocked_with_origin(domain, None)
    }

    /// Check if a domain is blocked with origin context
    pub fn is_blocked_with_origin(&self, domain: &str, origin: Option<&str>) -> bool {
        if domain.is_empty() {
            return false;
        }

        let reversed = Self::reverse_domain(domain);
        let reversed_origin = origin.map(Self::reverse_domain);

        self.is_blocked_reversed(&reversed, reversed_origin.as_deref())
    }

    fn is_blocked_reversed(&self, reversed: &str, origin: Option<&str>) -> bool {
        let mut current = &self.root;
        let mut remaining = reversed;

        loop {
            // Check rules at this node
            if let Some(origin_domain) = origin {
                // 1. Whitelist has highest priority - if origin is whitelisted, allow
                if let Some(whitelist) = &current.whitelist_origins {
                    if Self::origin_matches(origin_domain, whitelist) {
                        return false;
                    }
                }

                // 2. Blacklist (only-if) - block ONLY if origin matches
                if let Some(blacklist) = &current.blacklist_origins {
                    if Self::origin_matches(origin_domain, blacklist) {
                        return true;
                    }
                    // If blacklist exists but origin doesn't match, check children
                    // but don't apply universal block at this level
                } else if current.is_blocked {
                    // 3. Universal block applies if no blacklist exists
                    return true;
                }
            } else {
                // No origin provided - only universal blocks apply
                if current.is_blocked {
                    return true;
                }
            }

            if remaining.is_empty() {
                return false;
            }

            let first_char = remaining.chars().next().unwrap();

            if let Some(child) = current.children.get(&first_char) {
                let prefix = &child.prefix;

                if remaining.starts_with(prefix) {
                    remaining = &remaining[prefix.len()..];
                    current = child;
                } else {
                    // Prefix doesn't match
                    return false;
                }
            } else {
                // No matching child
                return false;
            }
        }
    }

    /// Check if an origin matches any pattern in the list (supports parent domain matching)
    fn origin_matches(origin: &str, patterns: &[String]) -> bool {
        for pattern in patterns {
            // Exact match
            if origin == pattern {
                return true;
            }

            // Parent domain match: if pattern is "com.example",
            // it matches "com.example.sub" (subdomains)
            if origin.starts_with(pattern) {
                let remaining = &origin[pattern.len()..];
                if remaining.is_empty() || remaining.starts_with('.') {
                    return true;
                }
            }
        }
        false
    }

    /// Find common prefix length
    fn common_prefix_len(s1: &str, s2: &str) -> usize {
        s1.chars()
            .zip(s2.chars())
            .take_while(|(a, b)| a == b)
            .count()
    }

    /// Serialize the tree to a binary file
    pub fn save_to_file(&self, path: &str) -> Result<(), std::io::Error> {
        let file = File::create(path)?;
        let mut writer = BufWriter::new(file);

        // Write magic header with version
        writer.write_all(b"DOMTREE2")?; // Version 2 with context support

        // Serialize the tree
        self.serialize_node(&self.root, &mut writer)?;

        writer.flush()?;
        Ok(())
    }

    fn serialize_node<W: Write>(
        &self,
        node: &RadixNode,
        writer: &mut W,
    ) -> Result<(), std::io::Error> {
        // Write prefix length and prefix
        let prefix_bytes = node.prefix.as_bytes();
        writer.write_all(&(prefix_bytes.len() as u32).to_le_bytes())?;
        writer.write_all(prefix_bytes)?;

        // Write is_blocked flag
        writer.write_all(&[if node.is_blocked { 1 } else { 0 }])?;

        // Write whitelist origins
        self.serialize_string_list(&node.whitelist_origins, writer)?;

        // Write blacklist origins
        self.serialize_string_list(&node.blacklist_origins, writer)?;

        // Write number of children
        writer.write_all(&(node.children.len() as u32).to_le_bytes())?;

        // Write each child
        for (key, child) in &node.children {
            writer.write_all(&(*key as u32).to_le_bytes())?;
            self.serialize_node(child, writer)?;
        }

        Ok(())
    }

    fn serialize_string_list<W: Write>(
        &self,
        list: &Option<Vec<String>>,
        writer: &mut W,
    ) -> Result<(), std::io::Error> {
        match list {
            None => {
                writer.write_all(&[0])?; // No list
            }
            Some(origins) => {
                writer.write_all(&[1])?; // Has list
                writer.write_all(&(origins.len() as u32).to_le_bytes())?;
                for origin in origins {
                    let bytes = origin.as_bytes();
                    writer.write_all(&(bytes.len() as u32).to_le_bytes())?;
                    writer.write_all(bytes)?;
                }
            }
        }
        Ok(())
    }

    /// Load tree from a binary file
    pub fn load_from_file(path: &str) -> Result<Self, std::io::Error> {
        let file = File::open(path)?;
        let mut reader = BufReader::new(file);

        // Check magic header
        let mut header = [0u8; 8];
        reader.read_exact(&mut header)?;

        // Support both version 1 and version 2
        let version = if &header == b"DOMTREE1" {
            1
        } else if &header == b"DOMTREE2" {
            2
        } else {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidData,
                "Invalid file format",
            ));
        };

        let root = Self::deserialize_node(&mut reader, version)?;

        Ok(DomainTree { root })
    }

    fn deserialize_node<R: Read>(reader: &mut R, version: u8) -> Result<RadixNode, std::io::Error> {
        // Read prefix
        let mut len_bytes = [0u8; 4];
        reader.read_exact(&mut len_bytes)?;
        let prefix_len = u32::from_le_bytes(len_bytes) as usize;

        let mut prefix_bytes = vec![0u8; prefix_len];
        reader.read_exact(&mut prefix_bytes)?;
        let prefix = String::from_utf8(prefix_bytes)
            .map_err(|_| std::io::Error::new(std::io::ErrorKind::InvalidData, "Invalid UTF-8"))?;

        // Read is_blocked flag
        let mut flag = [0u8; 1];
        reader.read_exact(&mut flag)?;
        let is_blocked = flag[0] == 1;

        // Read whitelist and blacklist (only in version 2)
        let whitelist_origins = if version >= 2 {
            Self::deserialize_string_list(reader)?
        } else {
            None
        };

        let blacklist_origins = if version >= 2 {
            Self::deserialize_string_list(reader)?
        } else {
            None
        };

        // Read children count
        let mut count_bytes = [0u8; 4];
        reader.read_exact(&mut count_bytes)?;
        let children_count = u32::from_le_bytes(count_bytes) as usize;

        let mut children = HashMap::new();
        for _ in 0..children_count {
            let mut key_bytes = [0u8; 4];
            reader.read_exact(&mut key_bytes)?;
            let key = char::from_u32(u32::from_le_bytes(key_bytes)).ok_or_else(|| {
                std::io::Error::new(std::io::ErrorKind::InvalidData, "Invalid char")
            })?;

            let child = Self::deserialize_node(reader, version)?;
            children.insert(key, Box::new(child));
        }

        Ok(RadixNode {
            prefix,
            is_blocked,
            whitelist_origins,
            blacklist_origins,
            children,
        })
    }

    fn deserialize_string_list<R: Read>(
        reader: &mut R,
    ) -> Result<Option<Vec<String>>, std::io::Error> {
        let mut flag = [0u8; 1];
        reader.read_exact(&mut flag)?;

        if flag[0] == 0 {
            return Ok(None);
        }

        let mut count_bytes = [0u8; 4];
        reader.read_exact(&mut count_bytes)?;
        let count = u32::from_le_bytes(count_bytes) as usize;

        let mut list = Vec::with_capacity(count);
        for _ in 0..count {
            let mut len_bytes = [0u8; 4];
            reader.read_exact(&mut len_bytes)?;
            let len = u32::from_le_bytes(len_bytes) as usize;

            let mut bytes = vec![0u8; len];
            reader.read_exact(&mut bytes)?;
            let s = String::from_utf8(bytes).map_err(|_| {
                std::io::Error::new(std::io::ErrorKind::InvalidData, "Invalid UTF-8")
            })?;
            list.push(s);
        }

        Ok(Some(list))
    }

    /// Bulk load domains from a list
    pub fn bulk_load(&mut self, domains: &[&str]) {
        for domain in domains {
            self.insert(domain);
        }
    }

    /// Count total blocked domains in the tree
    pub fn count_blocked(&self) -> usize {
        self.count_blocked_node(&self.root)
    }

    fn count_blocked_node(&self, node: &RadixNode) -> usize {
        let mut count = if node.is_blocked
            || node.whitelist_origins.is_some()
            || node.blacklist_origins.is_some()
        {
            1
        } else {
            0
        };
        for child in node.children.values() {
            count += self.count_blocked_node(child);
        }
        count
    }

    /// Get all blocked domains as a Vec
    pub fn get_all_blocked(&self) -> Vec<String> {
        let mut domains = Vec::new();
        self.collect_blocked(&self.root, String::new(), &mut domains);
        domains
    }

    fn collect_blocked(&self, node: &RadixNode, path: String, domains: &mut Vec<String>) {
        let current_path = if path.is_empty() {
            node.prefix.clone()
        } else {
            format!("{}{}", path, node.prefix)
        };

        if node.is_blocked || node.whitelist_origins.is_some() || node.blacklist_origins.is_some() {
            // Unreverse the domain before adding
            let domain = current_path.split('.').rev().collect::<Vec<_>>().join(".");
            domains.push(domain);
        }

        // Recursively collect from children
        for child in node.children.values() {
            self.collect_blocked(child, current_path.clone(), domains);
        }
    }
}

// ============================================================================
// FFI Interface for Flutter
// ============================================================================

#[no_mangle]
pub extern "C" fn domain_tree_new() -> *mut DomainTree {
    Box::into_raw(Box::new(DomainTree::new()))
}

#[no_mangle]
pub extern "C" fn domain_tree_free(tree: *mut DomainTree) {
    if !tree.is_null() {
        unsafe {
            let _ = Box::from_raw(tree);
        }
    }
}

#[no_mangle]
pub extern "C" fn domain_tree_insert(tree: *mut DomainTree, domain: *const c_char) -> bool {
    if tree.is_null() || domain.is_null() {
        return false;
    }

    unsafe {
        let tree = &mut *tree;
        let domain_str = match CStr::from_ptr(domain).to_str() {
            Ok(s) => s,
            Err(_) => return false,
        };
        tree.insert(domain_str)
    }
}

#[no_mangle]
pub extern "C" fn domain_tree_insert_with_whitelist(
    tree: *mut DomainTree,
    domain: *const c_char,
    origin: *const c_char,
) -> bool {
    if tree.is_null() || domain.is_null() || origin.is_null() {
        return false;
    }

    unsafe {
        let tree = &mut *tree;
        let domain_str = match CStr::from_ptr(domain).to_str() {
            Ok(s) => s,
            Err(_) => return false,
        };
        let origin_str = match CStr::from_ptr(origin).to_str() {
            Ok(s) => s,
            Err(_) => return false,
        };
        tree.insert_with_whitelist(domain_str, origin_str)
    }
}

#[no_mangle]
pub extern "C" fn domain_tree_insert_with_blacklist(
    tree: *mut DomainTree,
    domain: *const c_char,
    origin: *const c_char,
) -> bool {
    if tree.is_null() || domain.is_null() || origin.is_null() {
        return false;
    }

    unsafe {
        let tree = &mut *tree;
        let domain_str = match CStr::from_ptr(domain).to_str() {
            Ok(s) => s,
            Err(_) => return false,
        };
        let origin_str = match CStr::from_ptr(origin).to_str() {
            Ok(s) => s,
            Err(_) => return false,
        };
        tree.insert_with_blacklist(domain_str, origin_str)
    }
}

#[no_mangle]
pub extern "C" fn domain_tree_is_blocked(tree: *const DomainTree, domain: *const c_char) -> bool {
    if tree.is_null() || domain.is_null() {
        return false;
    }

    unsafe {
        let tree = &*tree;
        let domain_str = match CStr::from_ptr(domain).to_str() {
            Ok(s) => s,
            Err(_) => return false,
        };
        tree.is_blocked(domain_str)
    }
}

#[no_mangle]
pub extern "C" fn domain_tree_is_blocked_with_origin(
    tree: *const DomainTree,
    domain: *const c_char,
    origin: *const c_char,
) -> bool {
    if tree.is_null() || domain.is_null() {
        return false;
    }

    unsafe {
        let tree = &*tree;
        let domain_str = match CStr::from_ptr(domain).to_str() {
            Ok(s) => s,
            Err(_) => return false,
        };

        let origin_str = if origin.is_null() {
            None
        } else {
            match CStr::from_ptr(origin).to_str() {
                Ok(s) => Some(s),
                Err(_) => None,
            }
        };

        tree.is_blocked_with_origin(domain_str, origin_str)
    }
}

#[no_mangle]
pub extern "C" fn domain_tree_save(tree: *const DomainTree, path: *const c_char) -> bool {
    if tree.is_null() || path.is_null() {
        return false;
    }

    unsafe {
        let tree = &*tree;
        let path_str = match CStr::from_ptr(path).to_str() {
            Ok(s) => s,
            Err(_) => return false,
        };
        tree.save_to_file(path_str).is_ok()
    }
}

#[no_mangle]
pub extern "C" fn domain_tree_load(path: *const c_char) -> *mut DomainTree {
    if path.is_null() {
        return std::ptr::null_mut();
    }

    unsafe {
        let path_str = match CStr::from_ptr(path).to_str() {
            Ok(s) => s,
            Err(_) => return std::ptr::null_mut(),
        };

        match DomainTree::load_from_file(path_str) {
            Ok(tree) => Box::into_raw(Box::new(tree)),
            Err(_) => std::ptr::null_mut(),
        }
    }
}

#[no_mangle]
pub extern "C" fn domain_tree_bulk_load(
    tree: *mut DomainTree,
    domains: *const *const c_char,
    count: usize,
) -> bool {
    if tree.is_null() || domains.is_null() {
        return false;
    }

    unsafe {
        let tree = &mut *tree;
        let domain_ptrs = std::slice::from_raw_parts(domains, count);

        for &domain_ptr in domain_ptrs {
            if domain_ptr.is_null() {
                continue;
            }
            if let Ok(domain_str) = CStr::from_ptr(domain_ptr).to_str() {
                tree.insert(domain_str);
            }
        }
    }

    true
}

#[no_mangle]
pub extern "C" fn domain_tree_count_blocked(tree: *const DomainTree) -> usize {
    if tree.is_null() {
        return 0;
    }
    unsafe { (*tree).count_blocked() }
}

#[no_mangle]
pub extern "C" fn domain_tree_get_all_blocked(
    tree: *const DomainTree,
    out_domains: *mut *mut c_char,
    out_count: *mut usize,
) -> bool {
    if tree.is_null() || out_domains.is_null() || out_count.is_null() {
        return false;
    }

    unsafe {
        let tree = &*tree;
        let domains = tree.get_all_blocked();
        let count = domains.len();

        // Allocate array of C strings
        let c_strings: Vec<*mut c_char> = domains
            .into_iter()
            .map(|s| {
                let c_str = std::ffi::CString::new(s).unwrap();
                c_str.into_raw()
            })
            .collect();

        let boxed = c_strings.into_boxed_slice();
        *out_domains = Box::into_raw(boxed) as *mut c_char;
        *out_count = count;
        true
    }
}

#[no_mangle]
pub extern "C" fn domain_tree_free_string_array(domains: *mut *mut c_char, count: usize) {
    if domains.is_null() {
        return;
    }
    unsafe {
        let slice = std::slice::from_raw_parts_mut(domains, count);
        for &ptr in slice.iter() {
            if !ptr.is_null() {
                let _ = std::ffi::CString::from_raw(ptr);
            }
        }
        let _ = Box::from_raw(std::slice::from_raw_parts_mut(domains, count));
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_basic_insert_and_query() {
        let mut tree = DomainTree::new();

        assert!(tree.insert("example.com"));
        assert!(tree.is_blocked("example.com"));
        assert!(!tree.is_blocked("other.com"));
    }

    #[test]
    fn test_subdomain_blocking() {
        let mut tree = DomainTree::new();

        tree.insert("example.com");

        // Subdomains should be blocked
        assert!(tree.is_blocked("example.com"));
        assert!(tree.is_blocked("ads.example.com"));
        assert!(tree.is_blocked("tracker.ads.example.com"));

        // Other domains should not be blocked
        assert!(!tree.is_blocked("notexample.com"));
        assert!(!tree.is_blocked("example.org"));
    }

    #[test]
    fn test_whitelist_origin() {
        let mut tree = DomainTree::new();

        // Block doubleclick universally
        tree.insert("doubleclick.net");

        // But allow it on example.com
        tree.insert_with_whitelist("doubleclick.net", "example.com");

        // Without origin - blocked everywhere
        assert!(tree.is_blocked("doubleclick.net"));

        // With origin - allowed on example.com
        assert!(!tree.is_blocked_with_origin("doubleclick.net", Some("example.com")));
        assert!(!tree.is_blocked_with_origin("doubleclick.net", Some("sub.example.com")));

        // Still blocked on other origins
        assert!(tree.is_blocked_with_origin("doubleclick.net", Some("badsite.com")));
    }

    #[test]
    fn test_blacklist_origin() {
        let mut tree = DomainTree::new();

        // Block amazon-adsystem ONLY on annoyingsite.com
        tree.insert_with_blacklist("amazon-adsystem.com", "annoyingsite.com");

        // Without origin - not blocked
        assert!(!tree.is_blocked("amazon-adsystem.com"));

        // With non-matching origin - not blocked
        assert!(!tree.is_blocked_with_origin("amazon-adsystem.com", Some("goodsite.com")));

        // With matching origin - blocked
        assert!(tree.is_blocked_with_origin("amazon-adsystem.com", Some("annoyingsite.com")));
        assert!(tree.is_blocked_with_origin("amazon-adsystem.com", Some("sub.annoyingsite.com")));
    }

    #[test]
    fn test_multiple_domains() {
        let mut tree = DomainTree::new();

        tree.insert("ads.com");
        tree.insert("tracker.net");
        tree.insert("analytics.org");

        assert!(tree.is_blocked("ads.com"));
        assert!(tree.is_blocked("sub.ads.com"));
        assert!(tree.is_blocked("tracker.net"));
        assert!(tree.is_blocked("analytics.org"));
        assert!(!tree.is_blocked("google.com"));
    }

    #[test]
    fn test_serialization() {
        let mut tree = DomainTree::new();
        tree.insert("example.com");
        tree.insert_with_whitelist("ads.net", "goodsite.com");
        tree.insert_with_blacklist("tracker.org", "badsite.com");

        let path = "/tmp/test_tree_v2.bin";
        assert!(tree.save_to_file(path).is_ok());

        let loaded_tree = DomainTree::load_from_file(path).unwrap();

        // Test universal block
        assert!(loaded_tree.is_blocked("example.com"));
        assert!(loaded_tree.is_blocked("sub.example.com"));

        // Test whitelist
        assert!(!loaded_tree.is_blocked_with_origin("ads.net", Some("goodsite.com")));

        // Test blacklist
        assert!(loaded_tree.is_blocked_with_origin("tracker.org", Some("badsite.com")));
        assert!(!loaded_tree.is_blocked_with_origin("tracker.org", Some("othersite.com")));
    }

    #[test]
    fn test_bulk_load() {
        let mut tree = DomainTree::new();
        let domains = vec!["ads.com", "tracker.net", "analytics.org"];
        tree.bulk_load(&domains);

        assert!(tree.is_blocked("ads.com"));
        assert!(tree.is_blocked("tracker.net"));
        assert!(tree.is_blocked("analytics.org"));
    }

    #[test]
    fn test_count_blocked() {
        let mut tree = DomainTree::new();
        assert_eq!(tree.count_blocked(), 0);

        tree.insert("ads.com");
        assert_eq!(tree.count_blocked(), 1);

        tree.insert("tracker.net");
        tree.insert_with_whitelist("analytics.org", "goodsite.com");
        assert_eq!(tree.count_blocked(), 3);
    }

    #[test]
    fn test_priority_whitelist_over_universal() {
        let mut tree = DomainTree::new();

        // Universal block
        tree.insert("ads.com");

        // Whitelist should override
        tree.insert_with_whitelist("ads.com", "trustedsite.com");

        // Blocked without context
        assert!(tree.is_blocked("ads.com"));

        // Allowed with whitelisted origin
        assert!(!tree.is_blocked_with_origin("ads.com", Some("trustedsite.com")));

        // Still blocked with other origins
        assert!(tree.is_blocked_with_origin("ads.com", Some("othersite.com")));
    }

    #[test]
    fn test_blacklist_does_not_apply_universal() {
        let mut tree = DomainTree::new();

        // Only block on specific origin
        tree.insert_with_blacklist("conditional.com", "badsite.com");

        // Should NOT be blocked without origin
        assert!(!tree.is_blocked("conditional.com"));

        // Should NOT be blocked with different origin
        assert!(!tree.is_blocked_with_origin("conditional.com", Some("goodsite.com")));

        // Should be blocked ONLY with matching origin
        assert!(tree.is_blocked_with_origin("conditional.com", Some("badsite.com")));
    }
}
